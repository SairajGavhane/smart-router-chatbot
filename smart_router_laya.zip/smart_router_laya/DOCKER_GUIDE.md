# Run with Docker Desktop

Start Docker Desktop using Linux containers. Docker includes Python and dependencies, so a host `.venv` is unnecessary.

1. Open PowerShell in this extracted project folder.
2. Create the secret file if absent:

```powershell
if (!(Test-Path .streamlit\secrets.toml)) { Copy-Item .streamlit\secrets.toml.example .streamlit\secrets.toml }
```

3. Edit `.streamlit\secrets.toml` with your OpenRouter key. TypeSafe is optional for Laya and required for Jev Auto. You can reuse your earlier project's real secrets file. Do not paste keys into Dockerfile or compose.yaml.
4. Run:

```powershell
docker compose up --build -d
docker compose logs -f app
```

5. Open http://localhost:8502 and select Live → Auto → Laya. First prediction downloads the weights. Ctrl+C exits log-following without stopping the container.

## What Docker does

The Dockerfile starts from Python 3.12 slim, installs CPU PyTorch and requirements, copies the app, and runs Streamlit as a non-root user on container port 8501. Compose maps host localhost port 8502 to it, mounts your secrets read-only, and creates the `laya_models` named volume for Hugging Face downloads. The model is not embedded in the ZIP or image. A container restart reloads the model into RAM but reuses downloaded files. Host and Docker installations have separate caches.

The health check probes Streamlit's HTTP health endpoint. A healthy container does not prove Laya weights downloaded successfully or that API keys work; test a Live prompt as well. Docker Desktop must have enough RAM/disk available for model loading and inference; actual requirements should be measured on your machine.

## Commands

```powershell
docker compose ps
docker compose exec app python smoke_laya.py
docker compose restart app
docker compose down
```

After source/dependency changes: `docker compose up --build -d`.
After editing keys: `docker compose restart app`.
After a normal `docker compose down`, the model volume is retained. `docker compose down -v` also deletes downloaded model cache and will require a later download; use only if that is intended.

A missing-secret bind error means step 2/3 was skipped or the command is running from the wrong folder. This setup binds to your own computer, not a public network interface. Local Docker execution is packaging, not automatic internet deployment.
