# Jev + Laya Smart Router Chatbot

A Streamlit chatbot that classifies a request before choosing an economy or strong answer model through OpenRouter. This edition adds **local CPU Laya** while retaining hosted **Jev / TypeSafe** as an alternative. No retraining is performed.

Start with **START_HERE.md**. For containers, see **DOCKER_GUIDE.md**. Verification details are in **VALIDATION.md**.

## Pipeline

```mermaid
flowchart TD
    A[Streamlit question and conversation] --> B{Routing mode}
    B -->|Auto| C{Decision engine}
    B -->|Manual| G[Chosen answer model]
    C -->|Laya| D[Local CPU inference]
    C -->|Jev| E[TypeSafe API]
    D --> F{Valid decision and context?}
    E --> F
    F -->|No| X[Show error; stop]
    F -->|Yes| H{Low and confidence meets threshold?}
    H -->|Yes| I[Economy via OpenRouter]
    H -->|No| J[Strong via OpenRouter]
    G --> K[OpenRouter]
    I --> L[Response and usage ledger]
    J --> L
    K --> L
```

1. `app.py` loads saved settings, collects the question and maintains session history.
2. `core.py` builds a bounded context window, preserving complete prior user/assistant pairs.
3. In Auto mode, the chosen engine evaluates the same conversation passed to the answer model. The answer model also receives its own system instruction.
4. `laya_router.py` loads one CPU Laya router lazily, downloads weights on first use, and reuses the model in the process. Inference is serialized to limit concurrent memory pressure. It uses the multilingual model, a 2,048-token input budget and 512-token head budget. Truncated context or collapsed options stop the request before an answer API call.
5. Laya's `answer_confidence` is normalized into the shared route schema. Jev retains its own reported confidence. These scores are not interchangeable; each engine has its own experimental threshold setting (default 0.75).
6. Only a confident `low` decision uses economy. `high`, `uncertain`, or a below-threshold decision uses strong. Failure stops the turn; it does not silently fall back or retry.
7. OpenRouter produces the final answer. Default models are `openai/gpt-4.1-mini` and `openai/gpt-4.1`; users can change IDs and pricing in the sidebar.
8. The app records attempts, duration, token usage and API cost estimates. A local route has zero routing API charge; CPU/electricity/hosting costs are excluded. Failed API calls may still incur charges. The strong-only comparison is a same-token illustration, not measured savings.

## Files

| File | Role |
|---|---|
| app.py | Streamlit interface, settings, history and usage display |
| core.py | Shared routing policy, Jev/OpenRouter requests and accounting |
| laya_router.py | Optional local model adapter and context validation |
| requirements.txt | Base app dependencies; enough for Jev/Demo |
| requirements-laya.txt | Base dependencies plus pinned Laya 0.4.9 |
| setup_windows.bat / run_windows.bat | One-time Windows setup / normal launch |
| .streamlit/secrets.toml.example | Empty configuration template, safe to share |
| .streamlit/config.toml | Streamlit appearance/server configuration |
| Dockerfile / compose.yaml | CPU container, secret mount and persistent model cache |
| smoke_laya.py | Real local model diagnostic; no answer API call |
| test_core.py / test_laya.py | Offline behavior tests with fake responses |
| evaluation_prompts.json | Inherited sample evaluation prompts |
| README_JEV_BASE.md | Historical documentation from the base project |

## Evaluation and limitations

Demo uses keyword rules and placeholder answers. It does not demonstrate real Laya accuracy. Test in Live mode to evaluate the actual router. Try a simple conversion and then a detailed debugging/architecture problem, inspect the displayed tier and confidence, and repeat on a held-out set of your own prompts. Expected tiers are evaluation labels, not guaranteed model outputs. Compare answer quality, latency and total API costs against manual Strong mode before claiming savings. Do not tune and report performance on the same prompts.

No Laya API key is required. OpenRouter answers still require a valid key and provider credit/access. Jev Auto additionally requires a TypeSafe key. Local Laya routing does not make the whole chatbot offline: the answer conversation is sent to OpenRouter. The first Laya run needs internet access to download model files. CPU speed and memory use depend on the machine; this package does not guarantee a particular latency or 16 GB performance.

Secrets are read from environment variables first, then `.streamlit/secrets.toml`. Save them once. Never commit that real file. The Docker image excludes it and mounts it at runtime. Usage exports contain no keys, but may contain model/usage metadata. Session chat and ledger are not a persistent database.

This is a local prototype. Docker binds localhost only. Public multi-user hosting requires authentication, per-user quotas and suitable memory/CPU capacity. Changing Streamlit themes is independent of the routing engine.

## Provenance

Based on https://github.com/SairajGavhane/smart-router-chatbot at commit `3eabbdfe643c0706005374cd5dc29673b713452b`. This ZIP is a separate revision; the repository was not pushed or changed.

Laya upstream: https://github.com/NandhaKishorM/laya — package pinned to 0.4.9. Its published wheel was checked for the adapter's confidence and context metadata fields. Dependencies and downloaded weights remain subject to their own licenses and terms.
