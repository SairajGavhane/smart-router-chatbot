# Run on Windows

Extract this ZIP into a new folder, for example `C:\Users\Sairaj\Desktop\smart_router_laya`. Keep the earlier Jev project separately. This version uses http://localhost:8502 so it can coexist with your old app on 8501.

## Option A: run directly

1. Install Python 3.12 if needed. If your Python install manager supports it, run `py install 3.12`; otherwise install Python 3.12 from python.org, including the launcher. Confirm `py -3.12 --version` in a new PowerShell window.
2. Double-click `setup_windows.bat`. It creates `.venv`, installs CPU PyTorch and the app/Laya dependencies, and creates `.streamlit\secrets.toml` only if that file does not exist. Installation needs internet and can take time.
3. Open `.streamlit\secrets.toml` in VS Code and enter your key inside quotes:

```toml
OPENROUTER_API_KEY = "your-own-key"
TYPESAFE_API_KEY = ""
LOW_MODEL = "openai/gpt-4.1-mini"
HIGH_MODEL = "openai/gpt-4.1"
```

To also use Jev, enter your TypeSafe key. You may instead copy your existing Jev project's working `secrets.toml` into this new `.streamlit` folder. You do not need to enter keys each time. Do not share or upload the real secrets file.

4. Double-click `run_windows.bat`. Open http://localhost:8502.
5. In the sidebar select **Live → Auto → Laya**. Submit a short question. First inference downloads and loads the model; wait for it to finish. Subsequent requests reuse it. Demo is the startup default and does not call real models.
6. On future runs use only `run_windows.bat`. Stop the server with Ctrl+C in its terminal. Restart after editing saved keys.

PowerShell equivalents (from this extracted folder):

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements-laya.txt
# Copy only if secrets.toml does not already exist:
if (!(Test-Path .streamlit\secrets.toml)) { Copy-Item .streamlit\secrets.toml.example .streamlit\secrets.toml }
# Edit secrets.toml before Live mode.
.\.venv\Scripts\python.exe -m streamlit run app.py --server.port=8502
```

No virtual-environment activation is necessary with these commands. Stop if setup reports an error; later commands cannot work if the environment was not created.

## Test the actual local router

```powershell
.\.venv\Scripts\python.exe smoke_laya.py
```

This downloads/loads Laya and prints its normalized decision and elapsed time. It makes no paid answer API request. It is useful for seeing installation or model-download errors. The first-run duration includes download/loading time, so do not use it as a warm-inference benchmark.

In the app, try:
- Simple candidate: “Convert 2.5 kilometres to metres.”
- Complex candidate: “Design an order-processing service that prevents duplicate payments during retries. Explain idempotency keys, transaction boundaries and recovery after a crash.”

Inspect the engine, chosen tier, confidence, latency in the ledger and generated answer. Decisions may differ from expectations; record that as evaluation data rather than assuming all prompts route perfectly.

Offline regression checks: `.\.venv\Scripts\python.exe -m unittest discover -v`.

## Troubleshooting

- Missing Python/.venv: complete step 1 and rerun setup.
- Missing Laya/torch: rerun setup in this folder, then use this folder's run script.
- Download error: check Hugging Face connectivity, free disk space and the diagnostic traceback. Do not delete your secrets to retry.
- Slow inference/memory pressure: close other heavy apps, reduce conversation history and shorten prompts. CPU routing has real overhead. Jev or manual mode can be selected if local resources are insufficient.
- Input budget exceeded: start a new conversation, reduce “Previous conversation turns”, shorten the input, or select Jev. The app intentionally refuses to route from truncated Laya context.
- 401/402 or unavailable answer model: check OpenRouter key, credits and model access. Local routing does not provide free OpenRouter credits.
- Port in use: stop the other instance on 8502, or change the run script's port.

Use DOCKER_GUIDE.md for the container option. Do not start the direct and Docker versions on port 8502 simultaneously.
