# Validation of this ZIP

Checked 17 October 2026 in a Linux Python 3.12 environment:

- 20 offline unit tests passed: original Jev behavior, route escalation, context sharing, usage accounting, local routing without a TypeSafe key, manual bypass, local failures stopping paid calls, invalid confidence and incomplete input rejection.
- Streamlit AppTest: Demo render and chat submission passed.
- Streamlit AppTest: Live/Auto/Laya flow passed with mocked Laya and OpenRouter; one answer API attempt and one local routing record were recorded. No real credentials used.
- Python files compile; Streamlit TOML and Compose YAML parse.
- Published Laya 0.4.9 wheel inspected for answer_confidence, truncation metadata and Router options used by the adapter.
- ZIP checked for integrity and exclusion of actual secret files, model caches and virtual environments.

Not executed here: real Laya weight download/inference, real Jev/OpenRouter calls, Windows batch launch, or Docker image build/run. These require local runtime/network/provider resources. Therefore no measured routing accuracy, latency, RAM requirement or cost savings is claimed. Run smoke_laya.py and a Live prompt on your computer before presenting the integration as validated end-to-end.
