@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 (
    echo Python 3.12 is required. Install it, then run this again.
    pause
    exit /b 1
  )
)
.venv\Scripts\python.exe -m pip install torch --index-url https://download.pytorch.org/whl/cpu
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements-laya.txt
if errorlevel 1 goto failed
if not exist .streamlit\secrets.toml copy .streamlit\secrets.toml.example .streamlit\secrets.toml >nul
echo Setup complete. Add your OpenRouter key to .streamlit\secrets.toml.
echo TypeSafe key is optional unless using Jev. Then run run_windows.bat.
pause
exit /b 0
:failed
echo Installation failed. Read the error above before retrying.
pause
exit /b 1
