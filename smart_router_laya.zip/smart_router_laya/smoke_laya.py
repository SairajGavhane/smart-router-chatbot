"""Real model smoke test; downloads weights, but makes no paid answer API call."""
import json
import time
from laya_router import get_router, normalize_result

if __name__ == "__main__":
    questions = {"tier": {"type": "choice", "instructions": "Assess task complexity.",
        "criteria": {"low": "Simple definition or calculation.",
                     "high": "Complex reasoning or system design.",
                     "uncertain": "Cannot determine."}}}
    start = time.monotonic()
    result = get_router().predict("Convert 2.5 kilometres to metres.", questions,
                                  model="multilingual", max_len=2048, head_max_len=512)
    print(json.dumps(normalize_result(result), indent=2))
    print(f"Completed in {time.monotonic() - start:.1f}s (includes cold loading).")
