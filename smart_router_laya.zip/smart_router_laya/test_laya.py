import unittest
from core import AppError, Config, run_turn
from laya_router import normalize_result
from test_core import ANSWER, FakeAPI

def raw(choice='low', confidence=.95):
    return {'answers': {'tier': {'choice': choice, 'answer_confidence': confidence, 'confidence': .01}}, 'usage': {'truncated': False, 'state_tokens_dropped': 0}}

class LayaTests(unittest.TestCase):
    def test_answer_confidence_not_entropy(self):
        self.assertEqual(normalize_result(raw())['answers']['tier']['confidence'], .95)
    def test_invalid_confidence_rejected(self):
        for v in [None, True, -1, 2, float('nan')]:
            with self.assertRaises(AppError): normalize_result(raw(confidence=v))
    def test_incomplete_context_rejected(self):
        for usage in [{}, {'truncated': True}, {'truncated': False, 'state_tokens_dropped': 1}, {'truncated': False, 'options': {'tier': 'collapsed'}}]:
            value=raw(); value['usage']=usage
            with self.assertRaises(AppError): normalize_result(value)
    def test_local_only_calls_openrouter_with_same_context(self):
        api=FakeAPI(ANSWER); ledger=[]; seen=[]; c=Config(llm_key='test')
        def local(messages, config):
            seen.extend(messages); return normalize_result(raw())
        run_turn('Explain it', [{'role':'user','content':'Lists'}, {'role':'assistant','content':'A collection'}], c, ledger, transport=api, local_router=local)
        self.assertEqual(len(api.requests), 1)
        self.assertEqual(seen, api.requests[0][1]['messages'][1:])
        self.assertEqual(api.requests[0][1]['model'], c.low_model)
        self.assertEqual(ledger[0]['cost_usd'], 0)
    def test_uncertainty_escalates(self):
        for choice, confidence in [('uncertain', .99), ('low', .1), ('high', .95)]:
            c=Config(llm_key='test'); api=FakeAPI(ANSWER)
            run_turn('task', [], c, [], transport=api, local_router=lambda m,c: normalize_result(raw(choice, confidence)))
            self.assertEqual(api.requests[0][1]['model'], c.high_model)
    def test_local_failure_prevents_paid_call(self):
        api=FakeAPI(); ledger=[]
        def broken(m,c): raise AppError('local failure')
        with self.assertRaises(AppError): run_turn('task', [], Config(llm_key='test'), ledger, transport=api, local_router=broken)
        self.assertEqual(api.requests, [])
        self.assertEqual(ledger[0]['cost_usd'], 0)
    def test_manual_bypasses_local(self):
        def broken(m,c): self.fail('Manual must bypass router')
        api=FakeAPI(ANSWER)
        run_turn('task', [], Config(llm_key='test'), [], mode='Strong', transport=api, local_router=broken)
        self.assertEqual(len(api.requests), 1)
    def test_answer_failure_keeps_local_record(self):
        ledger=[]
        with self.assertRaises(AppError): run_turn('task', [], Config(llm_key='test'), ledger, transport=FakeAPI(AppError('timeout')), local_router=lambda m,c: normalize_result(raw()))
        self.assertEqual(len(ledger), 2)
        self.assertEqual(ledger[0]['cost_usd'], 0)
        self.assertIsNone(ledger[1]['cost_usd'])
